import 'package:bottomnavigationbar/developers.dart';
import 'package:flutter/material.dart';

class developerslist extends StatelessWidget{
 
  
  
  @override
  Widget build(BuildContext context) {
    // return new developerpage();

    return SingleChildScrollView(
      child:new Column(
        children: <Widget>[
          new developerpage(),
          new developerpage(),
          new developerpage(),
          new developerpage(),
        ],
      ),
    );
    
  }
}