import 'package:bottomnavigationbar/developers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'SizeConfig.dart';


class homePage extends StatefulWidget{
  @override
  _homePageState createState() => new _homePageState();
  
}
  
class _homePageState extends State<homePage>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black26,
      body: Container(
        
        padding: EdgeInsets.all(15.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: <Widget>[
            slotcard(text: "Slot Table",icon: Icons.today,warna: Colors.black,),
            allcard(text: "Today Evaluation",icon: Icons.check_box,warna: Colors.black,),
            allcard(text: "Time Table",icon: Icons.slow_motion_video,warna: Colors.black,),
            allcard(text: "CHARUSAT",icon: Icons.info,warna: Colors.black,),
          ],
          ),
          
      ),
    );
  }

  

}

class allcard extends StatelessWidget{
  allcard({this.text,this.icon,this.warna});
  final String text;
  final IconData icon;
  final Color warna;
  @override
  Widget build(BuildContext context) {
    return new Container(
     child: Card(
              margin: EdgeInsets.all(10.0),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.blue[900],
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      
                      Icon(
                        icon,
                        size: 50.0,
                        color: warna,
                        ),
                      Text(text,style:new TextStyle(fontSize:SizeConfig.safeBlockHorizontal),),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
  
  _onPressed(BuildContext context){
    showModalBottomSheet(
      context: context,
      builder: (sheetContext)=>BottomSheet(
        builder: (_)=>developerpage(),
        onClosing: (){},
      ),
      );
  }

}

class slotcard extends StatelessWidget{
  slotcard({this.text,this.icon,this.warna});
  final String text;
  final IconData icon;
  final Color warna;
  @override
  Widget build(BuildContext context) {
    return new Container(
     child: Card(
              margin: EdgeInsets.all(10.0),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
              child: InkWell(
                onTap: ()=>_onPressed(context),
                splashColor: Colors.blue[900],
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      
                      Icon(
                        icon,
                        size: 50.0,
                        color: warna,
                        ),
                      Text(text,style:new TextStyle(fontSize:SizeConfig.safeBlockHorizontal),),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
  
  _onPressed(BuildContext context){
    showModalBottomSheet(
      context: context,
      builder: (sheetContext)=>BottomSheet(
        builder: (_)=>developerpage(),
        onClosing: (){},
      ),
      );
  }

}