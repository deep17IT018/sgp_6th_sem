import 'package:flutter/material.dart';

class userpage extends StatelessWidget{

  @override
  Widget build(BuildContext context){
    return Container(
      color: Colors.black,
    );
  }
}